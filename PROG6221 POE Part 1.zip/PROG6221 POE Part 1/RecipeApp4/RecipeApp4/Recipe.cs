﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookOfRecipes
{
    internal class Recipe
    {
        public Recipe(Ingredient[] ingredients, Step[] steps)
        {
            //Declarations
            Ingredients = ingredients;
            Steps = steps;
        }

        public Ingredient[] Ingredients { get; }//get method for ingredients
        public Step[] Steps { get; }//get method for steps


    }
}
