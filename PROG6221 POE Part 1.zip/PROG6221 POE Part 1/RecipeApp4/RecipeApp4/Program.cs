﻿using BookOfRecipes;

internal class Program
{
   
    private static void Main(string[] args)
    {
        try
        {
            bool keepRunning = true;
            Console.WriteLine("Good day dear User");
            Console.WriteLine("Please close between the following");
            while (keepRunning)
            {
                Console.WriteLine("1. Enter recipe");
                Console.WriteLine("2. Display recipe");
                Console.WriteLine("3. Display steps");
                Console.WriteLine("4. Scale quantity");
                Console.WriteLine("5. Reset to original quantities");
                Console.WriteLine("6. Clear recipe");
                Console.WriteLine("7. Exit");

                Console.Write("Please enter your choice: ");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        EnterRecipe();
                        //This first case is where the user enters the recipe
                        break;
                    case 2:
                        DisplayRecipe();
                        //This second case is where the user displays the recipe
                        break;
                    case 3:
                        DisplaySteps();
                        //This third case is where the user displays the steps of the recipe
                        break;
                    case 4:
                        ScaleQuantity();
                        //This fourth case is where the user scales the quantity of the recipe
                        break;
                    case 5:
                        ResetToOriginalQuantities();
                        //This fifth case is where the user resets the quantity of the recipe to the original quantity
                        break;
                    case 6:
                        ClearRecipe();
                        //This sixth case is where the user clears the recipe and starts over
                        break;
                    case 7:
                        keepRunning = false;
                        //This seventh case is where the user exits the program
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        //This is the default case where the user is asked to enter a valid choice
                        break;
                }
            }
        } catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }

        Console.WriteLine("Thank you for using my software for you recipes");

    }
    static void EnterRecipe()
    {//This method is all about the Entry of recipes

        Console.Write("Please enter the number of ingredients: ");
        int numIngredients = int.Parse(Console.ReadLine());

        Ingredient[] ingredients = new Ingredient[numIngredients];//This is an array for ingredients

        for (int i = 0; i < numIngredients; i++)
        {
            Console.Write("Enter ingredient name: ");
            string name = Console.ReadLine();

            Console.Write("Enter ingredient quantity: ");
            double quantity = double.Parse(Console.ReadLine());

            Console.Write("Enter ingredient unit: ");
            string unit = Console.ReadLine();

            ingredients[i] = new Ingredient(name, quantity, unit);
        }

        Console.Write("Enter the number of steps: ");
        int numSteps = int.Parse(Console.ReadLine());

        Step[] steps = new Step[numSteps];
        //this is an array for the steps

        for (int i = 0; i < numSteps; i++)
        {
            Console.Write($"Enter step {i+1} description: ");
            string description = Console.ReadLine();

            steps[i] = new Step(description);
        }

        Recipe recipe = new Recipe(ingredients, steps);// This is where we declare
        CurrentRecipe = recipe;
    }

    static void DisplayRecipe()
    {
        if (CurrentRecipe == null)
        {
            Console.WriteLine("No recipe entered.");
            Console.WriteLine("Please try entering the recipe first");
            //This is what will display if theres no recipe entered
            return;
        }

        Console.WriteLine("Recipe:");
        Console.WriteLine("=============================");
        Console.WriteLine("Ingredients:");

        for (int i = 0; i < CurrentRecipe.Ingredients.Length; i++)
        {
            Ingredient ingredient = CurrentRecipe.Ingredients[i];
            Console.WriteLine($"{ingredient.Name}: {ingredient.GetQuantity()} {ingredient.Unit}");
        } //this is where the recipe is displayed

        Console.WriteLine("Steps:");

        for (int i = 0; i < CurrentRecipe.Steps.Length; i++)
        {
            Step step = CurrentRecipe.Steps[i];
            Console.WriteLine($"{i + 1}. {step.Description}");
            //This will display the steps
        }
    }

    static void DisplaySteps()
    {
        if (CurrentRecipe == null)
        {
            Console.WriteLine("No recipe entered.");
            //This is what will display if theres no recipe entered
            return;
        }
        //This is the method where the software will display the steps of the recipe
        //And it will display the steps of the recipe whenevethe user wants it
        Console.WriteLine("Steps:");

        for (int i = 0; i < CurrentRecipe.Steps.Length; i++)
        {
            Step step = CurrentRecipe.Steps[i];
            Console.WriteLine($"{i+1}. {step.Description}");
        }
    }

    static void ScaleQuantity()
    {
        if (CurrentRecipe == null)
        {
            Console.WriteLine("No recipe entered.");
            //This is what will display if theres no recipe entered
            return;
        }

        Console.Write("Enter scale factor (0.5, 2, or 3): ");
        double scaleFactor = double.Parse(Console.ReadLine());

        Ingredient.ScaleFactor = scaleFactor;
        //This is where the user will scale their quantites to the value they want
        Console.WriteLine("Recipe scaled.");
    }

    static void ResetToOriginalQuantities()
    {
        if (CurrentRecipe == null)
        {
            Console.WriteLine("No recipe entered.");
            //This is what will display if theres no recipe entered
            return;
        }

        for (int i = 0; i < CurrentRecipe.Ingredients.Length; i++)
        {
            Ingredient ingredient = CurrentRecipe.Ingredients[i];
            ingredient.Quantity = ingredient.OriginalQuantity;
        }

        Ingredient.ScaleFactor = 1;
        //This is the method whereby the user resets the quantity of the recipe to the original quantity
        Console.WriteLine("Quantities reset to original values you started with.");
    }

    static void ClearRecipe()
    {
        //method for clearing the recipe
        CurrentRecipe = null;
        Ingredient.ScaleFactor = 1;

        Console.WriteLine("Recipe cleared.");
    }

    static Recipe currentRecipe;
    static Recipe CurrentRecipe
    {
        get { return currentRecipe; }
        set { currentRecipe = value; }
        //Get and set methods for current recipe
    }
}