﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookOfRecipes
{
    internal class Ingredient
    {
        public Ingredient(string name, double quantity, string unit)
        {
            //Declarations
            Name = name;
            Quantity = quantity;
            Unit = unit;
            OriginalQuantity = quantity;
        }

        public string Name { get; set; }//get and set methods for Name
        public double Quantity { get; set; }//get and set methods for Quantity
        public string Unit { get; set; }//get and set methods for unit
        public double OriginalQuantity { get; }//get and set methods for Original Quantities

        public double GetQuantity()
        {
            return Quantity * ScaleFactor;
            //calculations for quantites and scale factor
        }

        public static double ScaleFactor
        {
            get; set;//get and set methods for Scal Factor
        }

    }
}
