﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookOfRecipes
{
    internal class Step
    {
        public Step(string description)
        {
            //Declarations
            Description = description;
        }

        public string Description { get; }//get method for description
    }
}
